# Assignment 2

Milestone 0: CMake and Unit Testing filled out. 

Milestone 1: PCB file loading and First Come First Served. 

Milestone 2: Shortest Job First, Shortest Remaining Time First, Round Robin, and analysis of algorithms. 

Note: 
You can manually copy the time analysis from console and paste it to this readme file, but directly output from your program is strongly recommended.     
---------------------------------------------------------------------------
Add your scheduling algorithm analysis below this line in a readable format. 
---------------------------------------------------------------------------
